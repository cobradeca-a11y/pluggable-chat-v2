import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ["LLM_PROVIDER"] = "mock"
os.environ["RATE_LIMIT_RPM"] = "15"
os.environ["ACTIVE_MIDDLEWARE"] = "rate_limit,request_logger"

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_plugins_endpoint():
    response = client.get("/api/plugins")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "providers" in data
    assert any(p["name"] == "mock" for p in data["providers"])
    assert any(p["name"] == "claude" for p in data["providers"])

def test_claude_registered():
    response = client.get("/api/plugins")
    data = response.json()
    claude_plugin = next((p for p in data["providers"] if p["name"] == "claude"), None)
    assert claude_plugin is not None
    assert claude_plugin["can_text"] is True
    # Claude does not generate images, but it supports them as attachments.
    assert claude_plugin["can_image"] is False
    assert claude_plugin["can_video"] is False
    assert "image/png" in claude_plugin["supported_attachments"]

def test_gpt4o_registered():
    response = client.get("/api/plugins")
    data = response.json()
    gpt4o_plugin = next((p for p in data["providers"] if p["name"] == "gpt4o"), None)
    assert gpt4o_plugin is not None
    assert gpt4o_plugin["can_text"] is True
    assert gpt4o_plugin["can_image"] is False
    assert gpt4o_plugin["can_video"] is False
    assert "image/png" in gpt4o_plugin["supported_attachments"]

def test_gemini_registered():
    response = client.get("/api/plugins")
    data = response.json()
    p = next((p for p in data["providers"] if p["name"] == "gemini"), None)
    assert p is not None
    assert p["can_text"] is True
    assert p["can_image"] is True
    assert p["can_video"] is True

def test_dalle3_registered():
    response = client.get("/api/plugins")
    data = response.json()
    p = next((p for p in data["providers"] if p["name"] == "dalle3"), None)
    assert p is not None
    assert p["can_text"] is False
    assert p["can_image"] is True
    assert p["can_video"] is False

def test_sora_registered():
    response = client.get("/api/plugins")
    data = response.json()
    p = next((p for p in data["providers"] if p["name"] == "sora"), None)
    assert p is not None
    assert p["can_text"] is False
    assert p["can_image"] is False
    assert p["can_video"] is True

def test_runway_registered():
    response = client.get("/api/plugins")
    data = response.json()
    p = next((p for p in data["providers"] if p["name"] == "runway"), None)
    assert p is not None
    assert p["can_text"] is False
    assert p["can_image"] is False
    assert p["can_video"] is True

def test_suno_registered():
    response = client.get("/api/plugins")
    data = response.json()
    p = next((p for p in data["providers"] if p["name"] == "suno"), None)
    assert p is not None
    assert p["can_text"] is False
    assert p["can_audio"] is True

def test_midjourney_registered():
    response = client.get("/api/plugins")
    data = response.json()
    p = next((p for p in data["providers"] if p["name"] == "midjourney"), None)
    assert p is not None
    assert p["can_text"] is False
    assert p["can_image"] is True
    assert p["can_video"] is False

def test_chat_sync():
    response = client.post(
        "/api/chat", 
        json={"messages": [{"role": "user", "content": "Olá"}]}
    )
    assert response.status_code == 200
    data = response.json()
    assert "content" in data
    assert data["content"] == "I am a mock response."

def test_chat_stream():
    with client.stream(
        "POST",
        "/api/chat/stream",
        json={"messages": [{"role": "user", "content": "Olá"}]}
    ) as response:
        assert response.status_code == 200
        assert "text/event-stream" in response.headers["content-type"]
        
        content = response.read().decode("utf-8")
        assert "data: I\n\n" in content
        assert "data: [DONE]\n\n" in content

def test_generate_video_mock():
    response = client.post(
        "/api/generate/video",
        json={"prompt": "test video", "provider": "kling"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "job_id" in data
    assert data["job_id"].startswith("kling_")

def test_check_video_status():
    response = client.post(
        "/api/generate/video",
        json={"prompt": "test video", "provider": "kling"}
    )
    job_id = response.json()["job_id"]
    
    response2 = client.get(f"/api/generate/video/{job_id}")
    assert response2.status_code == 200
    data2 = response2.json()
    assert data2["status"] == "completed"
    assert "progress" in data2
    assert "url" in data2

def test_rate_limit():
    # Rate limit was set to 15 requests per minute.
    status_codes = []
    for _ in range(15):
        resp = client.get("/api/health")
        status_codes.append(resp.status_code)
    
    assert 429 in status_codes
